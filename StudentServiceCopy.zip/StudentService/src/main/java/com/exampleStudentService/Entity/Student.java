package com.exampleStudentService.Entity;

public class Student {
	    private Long id;
	    private String name;
	    private String role;

}
