package com.example.Student.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String role;

    // Constructors, getters, and setters
    // (Getters and setters omitted for brevity)

    public Student() {
    }

    public Student(String name, String role) {
        this.name = name;
        this.role = role;
    }
	

}
