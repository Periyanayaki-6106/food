package com.example.Student.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Student.Entity.Student;
import com.example.Student.Repository.StudentRepo;
@Service
public class StudentServiceImpl implements StudentService{
	 @Autowired
	    private StudentRepo studentRepository;

	    @Override
	    public List<Student> getAllStudents() {
	        return studentRepository.findAll();
	    }

	    @Override
	    public Student getStudentById(Long id) {
	        return studentRepository.findById(id).orElse(null);
	    }

	    @Override
	    public Student createStudent(Student student) {
	        // Additional logic if needed (e.g., validation)
	        return studentRepository.save(student);
	    }

}
