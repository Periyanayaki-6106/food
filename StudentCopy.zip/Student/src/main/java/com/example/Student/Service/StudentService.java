package com.example.Student.Service;

import java.util.List;

import com.example.Student.Entity.Student;

public interface StudentService {
	List<Student> getAllStudents();
	 Student getStudentById(Long id);
	 Student createStudent(Student student);

}
